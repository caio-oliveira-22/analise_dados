import streamlit as st
import pandas as pd

st.write("Olá, Mundo")

nome = "Caio"
idade = "17"

st.write("Meu nome é ", nome, "e eu tenho ", idade," anos")




st.title("Meu Primeiro Dash")
st.subheader("Caio")


df = pd.DataFrame({
   'Materias': ["Portugês", "Matemática", "Python", "Frame"],
   'Notas': [5, 9, 7, 10]
 })
df

produtos = {
    "Carne": 2.50,
    "Chapeu": 15.90,
    "Arroz": 1.20,

}

st.title("Calculo da compra")

itens_escolhidos = st.multiselect(
    "Selecione os itens:",
    options=list(produtos.keys())
)

if itens_escolhidos:
    precos = [produtos[item] for item in itens_escolhidos]
    total = sum(precos)
    st.write(f"Valor Total: R$", total)