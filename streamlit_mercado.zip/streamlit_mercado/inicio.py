import streamlit as st
import pandas as pd

st.set_page_config(page_title= "Tikin de tudo", page_icon="🛒", layout="centered")

st.write("Olá, Mundo")

nome = "Caio"
idade = "17"

st.write("Meu nome é ", nome, "e eu tenho ", idade," anos")




st.title("Meu Primeiro Dash")
st.subheader("Caio")


df = pd.DataFrame({
   'Materias': ["Portugês", "Matemática", "Python", "Frame"],
   'Notas': [5, 9, 7, 10]
 })
df

produtos = {
    "Carne": 10.00,
    "Mexirica": 15.00,
    "Arroz": 5.00,
    "Feijão": 7.00

}

st.title("Calculo da compra")


itens_escolhidos = st.multiselect(
    "Selecione os itens:",
    options=list(produtos.keys())
)

col1, col2 = st.columns(2)


with col1:
 dinheiroC = st.number_input("Quanto você tem?", value=0.0, step=1.0)

with col2:
 Ctroco = st.number_input("Quanto vai gastar?", value=0.0, step=1.0)
 
 
operacao = st.selectbox(
    "Escolha como quer calcular a compra",
    options=["Adição (+)", "Subtração (-)", "Multiplicação (x)", "Divisão (/)"]
)

if st.button("Calcular", type="primary"):
    resultado = None
    
    if operacao == "Adição (+)":
        resultado = dinheiroC + Ctroco
        st.write("O Resultado é: ", resultado)  
        
    elif operacao == "Subtração (-)":
        resultado = dinheiroC - Ctroco
        st.write("O troco é: ", resultado)
        
    elif operacao == "Multiplicação (x)":
        resultado = dinheiroC * Ctroco
        st.write("O Resultado é: ", resultado)
        
    elif operacao == "Divisão (/)":
        if Ctroco != 0:
            resultado = dinheiroC / Ctroco
            st.write("O Resultado é: ", resultado)
            
        else:
            st.error("Erro: Não é possível dividir por zero")
            erro = True



if itens_escolhidos:
    precos = [produtos[item] for item in itens_escolhidos]
    total = sum(precos)
    st.write(f"Valor Total: R$", total)
    
    