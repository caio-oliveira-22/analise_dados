import pandas as pd
import matplotlib.pyplot as plt

# 1. Abrir o CSV com ; e vírgula decimal
df = pd.read_csv("Tabela4.csv", sep=";", decimal=",", encoding="latin1", header=None)

# 2. Limpar colunas vazias
df = df.dropna(axis=1, how="all")
df = df.iloc[1:].copy()

df.columns = ["Sigla", "Código", "Estado"] + [
    str(int(float(x))) for x in df.iloc[0, 3:]
]
df = df.iloc[1:].copy().reset_index(drop=True)

for c in df.columns[3:]:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# 3. Ordenar estados pelo maior IDH em 2024
df_ordenado = df.sort_values("2024", ascending=False)
print(df_ordenado[["Sigla", "Estado", "2024"]])

# 4. Maior melhora entre 1991 e 2024
df["Melhora"] = df["2024"] - df["1991"]
maior_melhora = df.loc[df["Melhora"].idxmax()]
print("\nEstado com maior melhora:")
print(maior_melhora[["Sigla", "Estado", "1991", "2024", "Melhora"]])

# 5. Estados que tiveram piora
pioraram = df[df["Melhora"] < 0]
print("\nEstados que tiveram piora:")
print(pioraram[["Sigla", "Estado", "1991", "2024", "Melhora"]])

# 5. Transformar para formato longo
anos = [c for c in df.columns if str(c).isdigit()]
id_vars = [c for c in df.columns if c not in anos]

df_longo = df.melt(
    id_vars=id_vars,
    value_vars=anos,
    var_name="Ano",
    value_name="IDH",
)
df_longo["Ano"] = df_longo["Ano"].astype(int)
df_longo["IDH"] = pd.to_numeric(df_longo["IDH"], errors="coerce")

# 6. Plotar apenas Minas Gerais
mg = df_longo[df_longo["Sigla"] == "MG"].sort_values("Ano")
fig, ax = plt.subplots(figsize=(12, 7))
ax.plot(mg["Ano"], mg["IDH"], marker="o", markersize=3, linewidth=1.5)
ax.set_title("Evolução do IDH de Minas Gerais (1991–2024)")
ax.set_xlabel("Ano")
ax.set_ylabel("IDH")
ax.set_ylim(0.3, 0.9)
fig.tight_layout()
plt.show()

# 7. Plotar a evolução do IDH de cada estado
fig, ax = plt.subplots(figsize=(12, 7))
for sigla, grupo in df_longo.groupby("Sigla"):
    grupo = grupo.sort_values("Ano")
    ax.plot(grupo["Ano"], grupo["IDH"], marker="o", markersize=3,
            linewidth=1.5, label=sigla)

ax.set_title("Evolução do IDH por estado (1991–2024)")
ax.set_xlabel("Ano")
ax.set_ylabel("IDH")
ax.set_ylim(0.3, 0.9)
ax.legend(ncol=3, bbox_to_anchor=(1.02, 1), loc="upper left", title="UF")
fig.tight_layout()
plt.show()
